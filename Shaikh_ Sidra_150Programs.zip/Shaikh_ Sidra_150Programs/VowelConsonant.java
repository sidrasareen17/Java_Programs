//Check whether an alphabet is vowel or consonant using if..else statement

public class VowelConsonant {
    public static void main(String[] args) {
        char ch = 'o';
        if(ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u' )
            System.out.println(ch + " is vowel");
        else
            System.out.println(ch + " is consonant");
    }
}

