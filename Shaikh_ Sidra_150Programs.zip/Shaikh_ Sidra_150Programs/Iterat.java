//Iterate through Set using iterator()
import java.util.Set;
import java.util.HashSet;
import java.util.Iterator;

class Iterate {
  public static void main(String[] args) {
    // Creating an Set
    Set<Integer> numbers = new HashSet<>();
    numbers.add(1);
    numbers.add(3);
    numbers.add(2);
    System.out.println("Set: " + numbers);

    // Creating an instance of Iterator
    Iterator<Integer> iterate = numbers.iterator();
    System.out.println("Iterating over Set:");
    while(iterate.hasNext()) {
      System.out.print(iterate.next() + ", ");
    }
  }
}
