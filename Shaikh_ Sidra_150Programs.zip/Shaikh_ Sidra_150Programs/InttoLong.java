//Java Program to Convert int to long using Typecasting
class InttoLong {
  public static void main(String[] args) {

    // create int variables
    int a = 25;
    int b = 34;

    // convert int into long
    // using typecasting
    long c = a;
    long d = b;

    System.out.println(c);    // 25
    System.out.println(d);    // 34
  }
}
