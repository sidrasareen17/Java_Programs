//Java Program to Convert int to double using Typecasting
class Main {
  public static void main(String[] args) {

    // create int variables
    int a =33;
    int b = 29;

    // convert int into double
    // using typecasting
    double c = a;
    double d = b;

    System.out.println(c);    // 33.0
    System.out.println(d);    // 29.0
  }
}
