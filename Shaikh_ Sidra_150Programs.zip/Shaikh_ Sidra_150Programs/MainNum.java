////Calculate the power of a number using pow() function
class MainNum {
  public static void main(String[] args) {
    int base = 3, exponent = -4;
    double result = Math.pow(base, exponent);
    System.out.println("Answer = " + result);
  }
}
 
    
}
