////Convert a String to ArrayList
import java.util.ArrayList;
import java.util.Arrays;

class StrToArr{
  public static void main(String[] args) {

    // create a string
    String str = "Java, JavaScript, Python";
    System.out.println("String: " + str);

    // convert the string into an array
    String[] arr = str.split(",");

    // create an arraylist from the string
    ArrayList<String> languages = new ArrayList<>(Arrays.asList(arr));
    System.out.println("ArrayList: " + languages);
  }
}
